import { useState } from "react";
import {
  ArrowRight,
  Award,
  BookOpen,
  ChevronRight,
  CircleHelp,
  ExternalLink,
  Flame,
  Heart,
  Lightbulb,
  MessageCircle,
  MoreHorizontal,
  Plus,
  Search,
  Send,
  Sparkles,
} from "lucide-react";
const posts = [
  [
    "How do I make a responsive navigation bar?",
    "Frontend",
    "Aarav S.",
    "12 min ago",
    18,
    42,
    "AS",
    "#7c3aed",
    true,
  ],
  [
    "Best approach for structuring a React project?",
    "React",
    "Priya M.",
    "38 min ago",
    12,
    31,
    "PM",
    "#00bea3",
  ],
  [
    "Looking for feedback on my portfolio design",
    "Showcase",
    "Rohan K.",
    "1 hr ago",
    8,
    24,
    "RK",
    "#f59e0b",
  ],
];
const doubts = [
  [
    "What is the difference between state and props?",
    "React fundamentals",
    6,
    "Meera P.",
  ],
  [
    "Can someone explain async / await with an example?",
    "JavaScript",
    3,
    "You can help",
  ],
  [
    "How should I prepare for a frontend interview?",
    "Career guidance",
    9,
    "Arjun R.",
  ],
];
const projects = [
  [
    "FocusFlow",
    "Productivity app",
    "Nisha Patel",
    "NP",
    "linear-gradient(135deg, #ff6d34, #f59e0b)",
    "F",
    128,
  ],
  [
    "Wanderly",
    "Travel platform",
    "Kabir Shah",
    "KS",
    "linear-gradient(135deg, #00bea3, #2563eb)",
    "W",
    96,
  ],
  [
    "GreenCart",
    "E-commerce concept",
    "Sara Khan",
    "SK",
    "linear-gradient(135deg, #7c3aed, #ec4899)",
    "G",
    84,
  ],
];
const Panel = ({ children, className = "" }) => (
  <section
    className={"rounded-xl p-5 sm:p-6 " + className}
    style={{
      background: "var(--card)",
      border: "1px solid var(--border)",
      boxShadow: "var(--card-shadow)",
    }}
  >
    {children}
  </section>
);
const CommunityDashboard = () => {
  const [tab, setTab] = useState("Trending");
  const [search, setSearch] = useState(false);
  const [liked, setLiked] = useState({});
  const [answerDrafts, setAnswerDrafts] = useState({});
  const [submittedAnswers, setSubmittedAnswers] = useState({});

  const submitAnswer = (title) => {
    const answer = answerDrafts[title]?.trim();
    if (!answer) return;
    setSubmittedAnswers((current) => ({ ...current, [title]: answer }));
    setAnswerDrafts((current) => ({ ...current, [title]: '' }));
  };
  return (
    <div className="space-y-5 pb-12 animate-fadeIn">
      <section
        className="relative overflow-hidden rounded-2xl p-6 sm:p-8"
        style={{
          background:
            "linear-gradient(120deg, #1a1f20 0%, #2d3436 58%, #174f4a 140%)",
        }}
      >
        <div
          className="absolute -right-8 -top-10 h-52 w-52 rounded-full opacity-20"
          style={{ background: "#00bea3", filter: "blur(8px)" }}
        />
        <div
          className="absolute bottom-[-90px] right-24 h-64 w-64 rounded-full opacity-20"
          style={{ border: "38px solid #ff6d34" }}
        />
        <div className="relative max-w-2xl">
          <span
            className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-bold"
            style={{
              background: "rgba(0,190,163,.16)",
              color: "#65e9d7",
              border: "1px solid rgba(0,190,163,.28)",
            }}
          >
            <Sparkles size={14} /> Community space
          </span>
          <h1 className="mt-4 text-3xl font-black tracking-tight text-white sm:text-4xl">
            Learn together. Build together.
          </h1>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-slate-300 sm:text-base">
            Ask questions, share your work, and grow with a community of curious
            builders.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <button
              className="inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-bold text-white shadow-lg hover:-translate-y-0.5"
              style={{ background: "var(--gradient-brand)" }}
            >
              <Plus size={17} /> Start a discussion
            </button>
            <button
              className="inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-bold text-white hover:bg-white/10"
              style={{ border: "1px solid rgba(255,255,255,.2)" }}
            >
              <CircleHelp size={17} /> Ask a doubt
            </button>
          </div>
        </div>
      </section>
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <Panel className="lg:col-span-2">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p
                className="text-xs font-bold uppercase tracking-[.18em]"
                style={{ color: "#ff6d34" }}
              >
                Community pulse
              </p>
              <h2
                className="mt-1 text-xl font-bold"
                style={{ color: "var(--text)" }}
              >
                Discussion forum
              </h2>
            </div>
            <button
              onClick={() => setSearch(!search)}
              className="inline-flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold"
              style={{
                color: "var(--text-soft)",
                background: "var(--input-bg)",
                border: "1px solid var(--border)",
              }}
            >
              <Search size={16} /> Search discussions
            </button>
          </div>
          {search && (
            <input
              autoFocus
              className="mt-4 w-full rounded-lg px-3 py-2.5 text-sm"
              placeholder="Search topics, tags, or members..."
              style={{
                color: "var(--text)",
                background: "var(--input-bg)",
                border: "1px solid var(--border)",
              }}
            />
          )}
          <div className="mt-5 flex gap-2 overflow-x-auto no-scrollbar">
            {["Trending", "Latest", "Following", "Unanswered"].map((name) => (
              <button
                key={name}
                onClick={() => setTab(name)}
                className="whitespace-nowrap rounded-full px-3.5 py-1.5 text-xs font-bold"
                style={{
                  background: tab === name ? "#ff6d34" : "var(--bg-soft)",
                  color: tab === name ? "#fff" : "var(--text-soft)",
                }}
              >
                {name}
              </button>
            ))}
          </div>
          <div
            className="mt-4 divide-y"
            style={{ borderColor: "var(--border)" }}
          >
            {posts.map(
              ([
                title,
                tag,
                author,
                time,
                replies,
                likes,
                initials,
                color,
                hot,
              ]) => (
                <article key={title} className="flex gap-3 py-4 first:pt-1">
                  <div
                    className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full text-xs font-black text-white"
                    style={{ background: color }}
                  >
                    {initials}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                        style={{ color, background: color + "1c" }}
                      >
                        {tag}
                      </span>
                      {hot && (
                        <span
                          className="inline-flex items-center gap-1 text-[10px] font-bold"
                          style={{ color: "#f59e0b" }}
                        >
                          <Flame size={12} /> Hot
                        </span>
                      )}
                    </div>
                    <h3
                      className="mt-1.5 text-sm font-bold leading-snug"
                      style={{ color: "var(--text)" }}
                    >
                      {title}
                    </h3>
                    <p
                      className="mt-1 text-xs"
                      style={{ color: "var(--muted)" }}
                    >
                      {author} - {time}
                    </p>
                  </div>
                  <div
                    className="flex flex-col items-end justify-center gap-2 text-xs"
                    style={{ color: "var(--muted)" }}
                  >
                    <span className="inline-flex items-center gap-1">
                      <MessageCircle size={14} /> {replies}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <Heart size={14} /> {likes}
                    </span>
                  </div>
                </article>
              ),
            )}
          </div>
          <button
            className="mt-4 inline-flex items-center gap-1.5 text-sm font-bold"
            style={{ color: "#ff6d34" }}
          >
            View all discussions <ArrowRight size={16} />
          </button>
        </Panel>
        <aside className="space-y-5">
          <Panel className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p
                  className="text-xs font-bold uppercase tracking-[.18em]"
                  style={{ color: "#00bea3" }}
                >
                  Community
                </p>
                <h2
                  className="mt-1 text-lg font-bold"
                  style={{ color: "var(--text)" }}
                >
                  Your impact
                </h2>
              </div>
              <Award size={24} style={{ color: "#f59e0b" }} />
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-center">
              {[
                ["12", "Replies"],
                ["48", "Points"],
                ["4", "Badges"],
              ].map(([value, label]) => (
                <div
                  key={label}
                  className="rounded-lg py-3"
                  style={{ background: "var(--bg-soft)" }}
                >
                  <p className="font-black" style={{ color: "var(--text)" }}>
                    {value}
                  </p>
                  <p
                    className="mt-0.5 text-[10px] font-semibold"
                    style={{ color: "var(--muted)" }}
                  >
                    {label}
                  </p>
                </div>
              ))}
            </div>
          </Panel>
          <Panel className="p-5">
            <div className="flex items-center justify-between">
              <h2
                className="text-lg font-bold"
                style={{ color: "var(--text)" }}
              >
                Topics to explore
              </h2>
              <MoreHorizontal size={19} style={{ color: "var(--muted)" }} />
            </div>
            <div className="mt-4 space-y-2">
              {[
                ["React", "1.8k members", "#7c3aed"],
                ["UI/UX Design", "1.2k members", "#ff6d34"],
                ["Career & Jobs", "980 members", "#00bea3"],
              ].map(([topic, count, color]) => (
                <button
                  key={topic}
                  className="flex w-full items-center gap-3 rounded-lg p-2 text-left hover:opacity-75"
                >
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{ background: color }}
                  />
                  <span
                    className="flex-1 text-sm font-semibold"
                    style={{ color: "var(--text)" }}
                  >
                    {topic}
                    <small
                      className="block text-xs font-normal"
                      style={{ color: "var(--muted)" }}
                    >
                      {count}
                    </small>
                  </span>
                  <ChevronRight size={16} style={{ color: "var(--muted)" }} />
                </button>
              ))}
            </div>
          </Panel>
        </aside>
      </div>
      <Panel>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p
              className="text-xs font-bold uppercase tracking-[.18em]"
              style={{ color: "#00bea3" }}
            >
              Get unstuck
            </p>
            <h2
              className="mt-1 text-xl font-bold"
              style={{ color: "var(--text)" }}
            >
              Doubt-solving corner
            </h2>
            <p className="mt-1 text-sm" style={{ color: "var(--muted)" }}>
              Questions from members waiting for a helpful answer.
            </p>
          </div>
          <button
            className="inline-flex self-start items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-bold text-white"
            style={{ background: "#00bea3" }}
          >
            <Send size={15} /> Ask a question
          </button>
        </div>
        <div className="mt-5 grid grid-cols-1 gap-3 md:grid-cols-3">
          {doubts.map(([title, subject, answers, helper]) => {
            const submittedAnswer = submittedAnswers[title];
            const answerCount = answers + (submittedAnswer ? 1 : 0);
            return (
              <article
                key={title}
                className="rounded-xl p-4"
                style={{ background: "var(--bg-soft)", border: "1px solid var(--border)" }}
              >
                <span className="inline-flex items-center gap-1.5 text-[11px] font-bold" style={{ color: "#7c3aed" }}>
                  <BookOpen size={13} /> {subject}
                </span>
                <h3 className="mt-2 min-h-11 text-sm font-bold leading-snug" style={{ color: "var(--text)" }}>
                  {title}
                </h3>
                <div className="mt-3 flex items-center justify-between text-xs">
                  <span className="font-semibold" style={{ color: "var(--muted)" }}>{answerCount} answers</span>
                  <span className="font-bold" style={{ color: helper === "You can help" ? "#ff6d34" : "#00a98f" }}>{helper}</span>
                </div>
                {submittedAnswer && (
                  <div className="mt-3 rounded-lg p-2.5 text-xs" style={{ background: "rgba(0,190,163,.10)", border: "1px solid rgba(0,190,163,.2)", color: "var(--text-soft)" }}>
                    <span className="font-bold" style={{ color: "#00a98f" }}>Your answer</span>
                    <p className="mt-1 leading-relaxed">{submittedAnswer}</p>
                  </div>
                )}
                <div className="mt-3 flex gap-2">
                  <input
                    value={answerDrafts[title] || ""}
                    onChange={(event) => setAnswerDrafts((current) => ({ ...current, [title]: event.target.value }))}
                    onKeyDown={(event) => { if (event.key === "Enter") submitAnswer(title); }}
                    className="min-w-0 flex-1 rounded-lg px-2.5 py-2 text-xs"
                    placeholder="Write an answer..."
                    aria-label={`Answer: ${title}`}
                    style={{ color: "var(--text)", background: "var(--card)", border: "1px solid var(--border)" }}
                  />
                  <button
                    onClick={() => submitAnswer(title)}
                    disabled={!answerDrafts[title]?.trim()}
                    className="inline-flex items-center justify-center rounded-lg px-2.5 text-white"
                    style={{ background: "#00bea3" }}
                    title="Submit answer"
                  >
                    <Send size={15} />
                  </button>
                </div>
              </article>
            );
          })}
        </div>      </Panel>
      <Panel>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p
              className="text-xs font-bold uppercase tracking-[.18em]"
              style={{ color: "#ff6d34" }}
            >
              Made by the community
            </p>
            <h2
              className="mt-1 text-xl font-bold"
              style={{ color: "var(--text)" }}
            >
              Project showcase
            </h2>
            <p className="mt-1 text-sm" style={{ color: "var(--muted)" }}>
              Fresh ideas and thoughtful work from fellow creators.
            </p>
          </div>
          <button
            className="inline-flex self-start items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-bold"
            style={{ color: "#ff6d34", background: "rgba(255,109,52,.10)" }}
          >
            <Plus size={16} /> Share your project
          </button>
        </div>
        <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {projects.map(
            ([title, type, author, initials, gradient, icon, likes]) => (
              <article
                key={title}
                className="overflow-hidden rounded-xl"
                style={{ border: "1px solid var(--border)" }}
              >
                <div
                  className="relative flex h-32 items-center justify-center"
                  style={{ background: gradient }}
                >
                  <span className="text-5xl font-black text-white/90">
                    {icon}
                  </span>
                  <button
                    className="absolute right-3 top-3 rounded-lg p-1.5 text-white"
                    style={{ background: "rgba(0,0,0,.18)" }}
                  >
                    <ExternalLink size={15} />
                  </button>
                </div>
                <div className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3
                        className="font-bold"
                        style={{ color: "var(--text)" }}
                      >
                        {title}
                      </h3>
                      <p
                        className="mt-0.5 text-xs"
                        style={{ color: "var(--muted)" }}
                      >
                        {type}
                      </p>
                    </div>
                    <button
                      onClick={() =>
                        setLiked({ ...liked, [title]: !liked[title] })
                      }
                      className="inline-flex items-center gap-1 text-xs font-bold"
                      style={{
                        color: liked[title] ? "#ff6d34" : "var(--muted)",
                      }}
                    >
                      <Heart
                        size={15}
                        fill={liked[title] ? "currentColor" : "none"}
                      />{" "}
                      {likes + (liked[title] ? 1 : 0)}
                    </button>
                  </div>
                  <div
                    className="mt-4 flex items-center gap-2 text-xs"
                    style={{ color: "var(--muted)" }}
                  >
                    <span
                      className="flex h-6 w-6 items-center justify-center rounded-full text-[9px] font-black text-white"
                      style={{ background: gradient }}
                    >
                      {initials}
                    </span>{" "}
                    By {author}
                  </div>
                </div>
              </article>
            ),
          )}
        </div>
        <button
          className="mt-5 inline-flex items-center gap-1.5 text-sm font-bold"
          style={{ color: "#ff6d34" }}
        >
          Explore all projects <ArrowRight size={16} />
        </button>
      </Panel>
      <button
        title="Open community assistant"
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full text-white shadow-lg hover:scale-105"
        style={{ background: "linear-gradient(135deg, #ff6d34, #00bea3)" }}
      >
        <Lightbulb size={23} />
      </button>
    </div>
  );
};
export default CommunityDashboard;
