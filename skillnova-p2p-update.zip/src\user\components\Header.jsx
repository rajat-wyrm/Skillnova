// ════════════════════════════════════════════════════════════
//  USER — components/Header.jsx
// ════════════════════════════════════════════════════════════
import { useState, useEffect, useMemo } from 'react';
import { Bell, Search, Sun, Moon, Menu } from 'lucide-react';
import { useAuthStore } from '../../lib/auth';
import { useNotifications } from '../../shared/hooks/useNotifications';
import { initials } from '../../lib/utils';
import { formatRelative } from '../../lib/utils';

const Header = ({ title, onMenuToggle, onNavigate }) => {
  const { user } = useAuthStore();
  const [dark, setDark] = useState(() => localStorage.getItem('theme') === 'dark');
  const [showNotif, setShowNotif] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { items, unreadCount, markRead, markAllRead } = useNotifications();

  useEffect(() => {
    if (dark) { document.documentElement.classList.add('dark'); localStorage.setItem('theme', 'dark'); }
    else { document.documentElement.classList.remove('dark'); localStorage.setItem('theme', 'light'); }
  }, [dark]);

  const searchOptions = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const base = [
      { label: 'Dashboard', page: 'dashboard', hint: 'Overview' },
      { label: 'Reports', page: 'reports', hint: 'Submit and track' },
      { label: 'Task Board', page: 'kanban', hint: 'Project tasks' },
      { label: 'Calendar', page: 'calendar', hint: 'Meetings' },
      { label: 'Knowledge Base', page: 'knowledge', hint: 'Articles' },
      { label: 'AI Assistant', page: 'ai', hint: 'Help' },
      { label: 'Files', page: 'files', hint: 'Uploads' },
      { label: 'Announcements', page: 'announcements', hint: 'Latest updates' },
    ];
    if (!query) return base.slice(0, 4);
    return base.filter((item) => `${item.label} ${item.hint}`.toLowerCase().includes(query));
  }, [searchQuery]);

  const goToSearchResult = (page) => {
    onNavigate?.(page);
    setSearchQuery('');
  };

  return (
    <header className="h-16 flex items-center px-3 sm:px-6 gap-2 sm:gap-4 flex-shrink-0" style={{ background: 'var(--card)', borderBottom: '1px solid var(--border)' }}>
      <button onClick={onMenuToggle} className="md:hidden p-2 rounded-lg -ml-2 mr-1" style={{ color: 'var(--muted)' }}>
        <Menu size={20} />
      </button>

      <div className="flex-1 min-w-0">
        <h1 className="text-base font-bold truncate" style={{ color: 'var(--text)' }}>{title}</h1>
      </div>

      <div className="relative hidden md:block">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: 'var(--muted)' }} />
        <input
          className="pl-9 pr-4 py-2 text-sm rounded-lg w-64 focus:outline-none"
          placeholder="Search pages…"
          style={{ background: 'var(--bg)', border: '1px solid var(--border)', color: 'var(--text)' }}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && searchOptions[0]) {
              e.preventDefault();
              goToSearchResult(searchOptions[0].page);
            }
          }}
          onFocus={(e) => (e.target.style.borderColor = '#ff6d34')}
          onBlur={(e) => (e.target.style.borderColor = 'var(--border)')}
        />
        {searchQuery && (
          <div className="absolute left-0 right-0 top-11 rounded-xl shadow-xl z-50 overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            {searchOptions.length === 0 ? (
              <p className="px-3 py-2 text-xs" style={{ color: 'var(--muted)' }}>No matches</p>
            ) : searchOptions.map((item) => (
              <button key={item.page} onMouseDown={() => goToSearchResult(item.page)} className="w-full text-left px-3 py-2 hover:bg-white/5" style={{ color: 'var(--text)' }}>
                <p className="text-sm font-medium">{item.label}</p>
                <p className="text-[11px] mt-0.5" style={{ color: 'var(--muted)' }}>{item.hint}</p>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center gap-1 relative">
        <button onClick={() => setDark(!dark)} className="p-2 rounded-lg" style={{ color: 'var(--muted)' }}>
          {dark ? <Sun size={18} /> : <Moon size={18} />}
        </button>
        <button onClick={() => setShowNotif(!showNotif)} className="relative p-2 rounded-lg" style={{ color: 'var(--muted)' }}>
          <Bell size={18} />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full text-[10px] font-bold flex items-center justify-center text-white" style={{ background: '#ff6d34' }}>
              {unreadCount}
            </span>
          )}
        </button>
        {showNotif && (
          <div className="absolute right-0 top-12 w-80 max-h-[70vh] overflow-y-auto rounded-2xl shadow-xl z-50"
            style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="px-4 py-3 flex items-center justify-between" style={{ borderBottom: '1px solid var(--border)' }}>
              <p className="text-sm font-semibold" style={{ color: 'var(--text)' }}>Notifications</p>
              <button onClick={markAllRead} className="text-xs hover:underline" style={{ color: '#ff6d34' }}>Mark all read</button>
            </div>
            {items.length === 0 ? (
              <p className="px-4 py-6 text-center text-xs" style={{ color: 'var(--muted)' }}>You're all caught up 🎉</p>
            ) : items.map((n) => (
              <button key={n.id} onClick={() => markRead(n.id)} className="w-full text-left px-4 py-3 flex gap-3" style={{ borderBottom: '1px solid var(--border)' }}>
                {!n.read && <div className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ background: '#ff6d34' }} />}
                <div className={n.read ? 'pl-5' : ''}>
                  <p className="text-xs leading-snug font-medium" style={{ color: 'var(--text)' }}>{n.title}</p>
                  {n.body && <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{n.body}</p>}
                  <p className="text-xs mt-1" style={{ color: 'var(--muted)' }}>{formatRelative(n.createdAt)}</p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 sm:gap-2.5 pl-2 sm:pl-3" style={{ borderLeft: '1px solid var(--border)' }}>
        <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0 shadow-md"
          style={{ background: 'linear-gradient(135deg, #ff6d34, #00bea3)' }}>
          {initials(user?.name)}
        </div>
        <div className="hidden md:block">
          <p className="text-xs font-semibold leading-none" style={{ color: 'var(--text)' }}>{user?.name}</p>
          <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{user?.department || user?.role}</p>
        </div>
      </div>
    </header>
  );
};

export default Header;
